/* 
Copyright (C) 2026 Tomáš Mark

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

const CACHE_DIR = GLib.build_filenamev([GLib.get_user_cache_dir(), 'blur-wallpaper']);

export default class BlurWallpaperExtension extends Extension {
    constructor(metadata) {
        super(metadata);
    }

    // ── Pre-blurred image (static desktop blur) ───────────────────────────────
    // Blur is baked into a wallpaper file via ImageMagick and applied through
    // org.gnome.desktop.background – no GPU effect on the background group,
    // so workspace transitions never touch the blur at all.

    // Returns the URI of the blurred cached image, or null on failure.
    async _blurImage(pictureUri, sigma) {
        if (!pictureUri) return null;

        const picturePath = Gio.File.new_for_uri(pictureUri).get_path();
        if (!picturePath) return null;

        // ── Cache lookup ─────────────────────────────────────────────────
        const cacheKey = GLib.compute_checksum_for_string(
            GLib.ChecksumType.SHA256, `${picturePath}:${sigma}`, -1
        );
        const cachedPath = GLib.build_filenamev([CACHE_DIR, `${cacheKey}.jpg`]);
        const cacheFile  = Gio.File.new_for_path(cachedPath);

        let cacheHit = false;
        if (cacheFile.query_exists(null)) {
            const ci = cacheFile.query_info('time::modified', Gio.FileQueryInfoFlags.NONE, null);
            const si = Gio.File.new_for_path(picturePath)
                          .query_info('time::modified', Gio.FileQueryInfoFlags.NONE, null);
            cacheHit = ci.get_attribute_uint64('time::modified') >=
                       si.get_attribute_uint64('time::modified');
        }

        if (!cacheHit) {
            GLib.mkdir_with_parents(CACHE_DIR, 0o755);
            const threads = String(GLib.get_num_processors());
            const proc = Gio.Subprocess.new(
                ['magick', '-limit', 'thread', threads, picturePath, '-blur', `0x${sigma}`, cachedPath],
                Gio.SubprocessFlags.STDOUT_SILENCE | Gio.SubprocessFlags.STDERR_SILENCE
            );
            await new Promise((resolve, reject) => {
                proc.wait_async(null, (self, result) => {
                    try {
                        self.wait_finish(result);
                        resolve();
                    } catch (e) {
                        reject(e);
                    }
                });
            });
            if (!this._bgSettings) return null;
            if (!proc.get_successful()) return null;
        }

        return cacheFile.get_uri();
    }

    _requestBlurUpdate() {
        this._generation = (this._generation ?? 0) + 1;

        if (this._applying) {
            this._pendingApply = true;
            return;
        }

        this._generateAndApplyBlurredWallpaper(this._generation);
    }

    _isCurrentBlurJob(generation, sourceUri, sourceUriDark, sigma) {
        return this._bgSettings &&
            generation === this._generation &&
            sourceUri === this._sourceUri &&
            sourceUriDark === this._sourceUriDark &&
            sigma === Math.round(this._blurRadius);
    }

    async _generateAndApplyBlurredWallpaper(generation) {
        if (this._applying || !this._bgSettings) return;
        this._applying = true;

        try {
            const sourceUri     = this._sourceUri     ?? this._bgSettings.get_string('picture-uri');
            const sourceUriDark = this._sourceUriDark ?? this._bgSettings.get_string('picture-uri-dark');
            if (!sourceUri) return;

            const sigma = Math.round(this._blurRadius);
            if (sigma <= 0) {
                this._restoreWallpaper();
                return;
            }

            // Blur light wallpaper
            const blurredUri = await this._blurImage(sourceUri, sigma);
            if (!this._isCurrentBlurJob(generation, sourceUri, sourceUriDark, sigma)) return;
            if (!blurredUri) return;

            // Blur dark wallpaper separately when it differs from the light one;
            // otherwise reuse the already-blurred light image.
            let blurredUriDark = blurredUri;
            if (sourceUriDark && sourceUriDark !== sourceUri) {
                blurredUriDark = (await this._blurImage(sourceUriDark, sigma)) ?? blurredUri;
                if (!this._isCurrentBlurJob(generation, sourceUri, sourceUriDark, sigma)) return;
            }

            // Preserve originals before first overwrite
            if (!this._originalUri) {
                this._originalUri     = sourceUri;
                this._originalUriDark = sourceUriDark || sourceUri;
            }

            this._settingBlur = true;
            this._bgSettings.set_string('picture-uri',      blurredUri);
            this._bgSettings.set_string('picture-uri-dark', blurredUriDark);
            this._settingBlur = false;
        } catch (e) {
            console.error(`BlurWallpaper: convert failed – ${e.message}`);
        } finally {
            this._settingBlur = false;
            this._applying = false;
            if (this._pendingApply && this._bgSettings) {
                this._pendingApply = false;
                this._generateAndApplyBlurredWallpaper(this._generation);
            }
        }
    }

    _restoreWallpaper() {
        if (!this._originalUri || !this._bgSettings) return;
        this._settingBlur = true;
        this._bgSettings.set_string('picture-uri', this._originalUri);
        this._bgSettings.set_string('picture-uri-dark', this._originalUriDark ?? this._originalUri);
        this._settingBlur = false;
        this._originalUri = null;
        this._originalUriDark = null;
        // Cached files are intentionally kept in CACHE_DIR for reuse.
    }

    _isManagedBlurUri(uri) {
        if (!uri || !this._cacheDirUri)
            return false;
        return uri.startsWith(`${this._cacheDirUri}/`);
    }

    _onBackgroundChanged() {
        if (this._settingBlur || !this._bgSettings)
            return;

        const currentUri = this._bgSettings.get_string('picture-uri');
        const currentUriDark = this._bgSettings.get_string('picture-uri-dark');

        const nextSourceUri = this._isManagedBlurUri(currentUri)
            ? this._sourceUri
            : currentUri;
        const nextSourceUriDark = this._isManagedBlurUri(currentUriDark)
            ? this._sourceUriDark
            : currentUriDark;

        if (nextSourceUri === this._sourceUri && nextSourceUriDark === this._sourceUriDark)
            return;

        this._sourceUri = nextSourceUri;
        this._sourceUriDark = nextSourceUriDark;
        this._originalUri = this._sourceUri;
        this._originalUriDark = this._sourceUriDark;

        this._requestBlurUpdate();
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    _initBlur() {
        this._blurRadius = this._settings?.get_int('intensity') ?? 0;
        this._applying = false;
        this._pendingApply = false;
        this._generation = 0;
        this._settingBlur = false;
        this._cacheDirUri = Gio.File.new_for_path(CACHE_DIR).get_uri();
        this._sourceUri = this._bgSettings.get_string('picture-uri');
        this._sourceUriDark = this._bgSettings.get_string('picture-uri-dark');
        this._originalUri = this._sourceUri;
        this._originalUriDark = this._sourceUriDark;

        this._bgSettings.connectObject('changed::picture-uri', () => this._onBackgroundChanged(), this);
        this._bgSettings.connectObject('changed::picture-uri-dark', () => this._onBackgroundChanged(), this);
        this._requestBlurUpdate();
    }

    _refreshRadius() {
        const nextRadius = this._settings?.get_int('intensity') ?? 0;
        if (nextRadius === this._blurRadius) return;
        this._blurRadius = nextRadius;
        this._requestBlurUpdate();
    }

    enable() {
        this._settings = this.getSettings();
        this._bgSettings = new Gio.Settings({ schema: 'org.gnome.desktop.background' });
        this._initBlur();

        this._settings?.connectObject('changed::intensity', () => this._refreshRadius(), this);
    }

    disable() {
        this._settings?.disconnectObject(this);
        this._bgSettings?.disconnectObject(this);
        this._settings = null;

        this._restoreWallpaper();
        this._bgSettings = null;
        this._blurRadius = null;
        this._sourceUri = null;
        this._sourceUriDark = null;
        this._cacheDirUri = null;
        this._generation = 0;
        this._pendingApply = false;
    }
}
